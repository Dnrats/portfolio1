// const button = document.getElementById('details')
// button.addEventListener('click', flipCard)
// const button2 = document.getElementById('back-button')
// button2.addEventListener('click', flipCard)
// const button3 = document.getElementById('details2')
// button3.addEventListener('click', flipCard2)
// const button4 = document.getElementById('back-button2')
// button4.addEventListener('click', flipCard2)




let buttons = document.querySelectorAll('.buttons')
// buttons.addEventListener('click', flipCard());

// function flipCard() {
   let card = document.querySelectorAll('.card'); 

   // card.classList.add('flipCard');
   card.forEach.addEventListener('click', function() {
      card.classList.add('flipCard')
   })



// const image = document.querySelector('.fa-image');
// const modalOpened = document.querySelector('.modal-container');
// const closeButton = document.querySelector('.fa-xmark');

// closeButton.addEventListener('click', hideImage);
// image.addEventListener('click', showImage);
// button.addEventListener('click', flipCard);

// for (i of buttons) {
//     (function(i) {
//         i.addEventListener('click', function() {
//             card.classList.toggle("flipCard");
//         });
//     })(i);
// }



// function showImage() {
//   modalOpened.style.display = "flex";
// }

// function hideImage() {
//     modalOpened.style.display = "none"
// }



// function flipCard2() {
//     card2.classList.toggle('flipCard')
//  }
// button.forEach((button) => button.addEventListener("click", flipCard));