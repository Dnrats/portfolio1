function sendEmail() {
    Email.send({
        Host : "smtp.elasticemail.com",
        Username : "contact@dnrats.com",
        Password : "CF25C966F48946D336E4BED6685EAA7FDE93",
        To : 'artemfr@hotmail.com',
        From : 'contact@dnrats.com', 
        ReplyForm : document.getElementById("Email").value,
        Subject : "New Contact Form",
        Body : "Name: " + document.getElementById("Name").value
        + "<br> Email: " + document.getElementById("Email").value
        +"<br> Message " + document.getElementById("Message").value
    }).then(
      message => alert(message)
    );
}