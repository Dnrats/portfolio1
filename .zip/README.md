# portfolio1
Nothing much to say. Just a portfolio

# Tools
Mainly HTML and CSS. Eventually I'll add some animations. So far I used JavaScript only for contact form, to avoid using PHP.